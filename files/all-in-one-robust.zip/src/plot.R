
# read data
lapply(1:K, matrix, data=NA, nrow=1, ncol=n)
for(i in c(1:11)) {
  weight <- read.csv(file=paste("weights/iter", i))
  weight_iters[[i]] <- weight
}

iters <- rep(c("Second", "Median1", "Median2", "Last"), each=n)
type <- rep(c(rep("Inliers", n - n * eps), rep("Outliers", n * eps)), 4)
weights <- c(c(weight_iters[[1]]$V1[1:(n - n * eps)], weight_iters[[1]]$V1[(n - n * eps + 1):n]), 
             c(weight_iters[[4]]$V1[1:(n - n * eps)], weight_iters[[4]]$V1[(n - n * eps + 1):n]), 
             c(weight_iters[[8]]$V1[1:(n - n * eps)], weight_iters[[8]]$V1[(n - n * eps + 1):n]), 
             c(weight_iters[[K]]$V1[1:(n - n * eps)], weight_iters[[K]]$V1[(n - n * eps + 1):n])
)

data <- data.frame(iters, type, weights)
new_order <- with(data, reorder(iters, weights, mean, na.rm=TRUE))

par(mar=c(3,4,3,1))
postscript(file="boxplot_flip.ps")
b_plot <- boxplot(abs(weights) ~ type * new_order, data=data, 
                  boxwex=0.4, xlab="Iterations", ylab="Weights",
                  main="Weight revolution over time", #log="y",
                  col=c("slateblue1", "tomato"), pch=1,
                  xaxt="n")

names_ <- sapply(strsplit(b_plot$names , '\\.') , function(x) x[[2]] )
names_ <- names_[seq(1 , length(names_), 2)]
names_ <- c("k=1", "k=4", "k=8", "k=12")
axis(1, 
     at = seq(1.5 , 8 , 2), 
     labels = names_ , 
     tick=FALSE , cex=0.3)

for(i in seq(0.5 , 10 , 2)){ 
  abline(v=i,lty=1, col="grey")
}

legend("topright", legend = c("Inliers", "Outliers"), 
       col=c("slateblue1" , "tomato"),
       pch = 15, bty = "n", pt.cex = 3, cex = 1.2,  horiz = F, inset = c(0.1, 0.1))

dev.off()
