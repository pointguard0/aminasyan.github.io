# Iterative reweighted mean estimator

This repository contains the implementation of Algorithm 1 from https://arxiv.org/pdf/2002.01432.pdf. It also contains the codes of experiments provided in the paper. 