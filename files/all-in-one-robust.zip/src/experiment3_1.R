# setwd("~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/iterative-sdp/src")
# setwd("~/iterative-sdp/src")
source("iterative-reweighting.R")


n <- 500
p <- 20

Sigma <- eye(p)

num_trials <- 1
step <- 20 
N <- 1000
step_range <- N / step

file.create(paste("it", 0))

for(tr in 1:num_trials) {
  
  means <- list()
  medians <- list()
  geo_medians <- list()
  oracles <- list()
  mus <- list()
  
  for(i in 0:50) {
    eps <- i / 100
    # generate X 
    X <- generate_X(n, p, eps, Sigma, outlier_type = "large")
    
    # compute estimators
    mu_hat <- mu_IR(X, eps, Sigma)
    sample_mean <- apply(X, 2, mean)
    sample_med <- apply(X, 2, median)
    geo_med <- geo_median(X)$p
    inlier_mean <- apply(X[1:(n - n * eps), ], 2, mean)
    
    mus <- c(mus, norm(mu_hat, type="2"))
    means <- c(means, norm(sample_mean, type="2"))
    medians <- c(medians, norm(sample_med, type="2"))
    geo_medians <- c(geo_medians, norm(geo_med, type="2"))
    oracles <- c(oracles, norm(inlier_mean, type="2"))
  }
  
  if (tr > 1) {
    
    for(j in 1:51) {
      mus_mean[[j]] <- mus_mean[[j]] + mus[[j]]
      means_mean[[j]] <- means_mean[[j]] + means[[j]]
      medians_mean[[j]] <- medians_mean[[j]] + medians[[j]]
      geo_medians_mean[[j]] <- geo_medians_mean[[j]] + geo_medians[[j]]
      oracles_mean[[j]] <- oracles_mean[[j]] + oracles[[j]]
    }
    
  } else {
    mus_mean <- mus
    means_mean <- means
    medians_mean <- medians
    geo_medians_mean <- geo_medians
    oracles_mean <- oracles
  }
  file.create(paste("it", tr))
}

for(j in 1:51){
  mus_mean[[j]] <- mus_mean[[j]] / num_trials
  means_mean[[j]] <- means_mean[[j]] / num_trials
  medians_mean[[j]] <- medians_mean[[j]] / num_trials
  geo_medians_mean[[j]] <- geo_medians_mean[[j]] / num_trials
  oracles_mean[[j]] <- oracles_mean[[j]] / num_trials
}


# ձայնագրում ենք 
write(mus_mean, "Estimated")
write(means_mean, "Sample")
write(medians_mean, "Median")
write(geo_medians_mean, "Geometric")
write(oracles_mean, "Oracle")


postscript(file="comparison_4-10.ps")

pdf(file="comparison_4-10.pdf")

cl <- rainbow(10)
plot(0.6, 0.5, xlab="eps",
     ylab="l2 loss",
     xlim = c(0,0.5), ylim = c(0,16),
     type = "n", main="Estimator comparison", cex.main=2., cex.lab=2, cex.axis=2)
lines(x=c(0:50) / 100, y=mus_mean, type='b', col=cl[1], pch=17)

lines(x=c(0:50) / 100, y=means_mean, type='b', col=cl[2], pch=15)
lines(x=c(0:50) / 100, y=medians_mean, type='b', col=cl[7], pch=18)
lines(x=c(0:50) / 100, y=geo_medians_mean, type='b', col=cl[10], pch=4)
lines(x=c(0:50) / 100, y=oracles_mean, type='b')
legend("topleft", legend = c("Estimated Mu",
                             "Sample Mean",
                             "Sample Median",
                             "Geometric Median", 
                             "Oracle"), col=c(cl[c(1, 2, 7, 10)], "black"),
       pch=c(17, 15, 18, 4, 1), cex=2., pt.cex = 1) # optional legend

# lines(x=c(0:50) / 100, y=y, type='b')

dev.off()

