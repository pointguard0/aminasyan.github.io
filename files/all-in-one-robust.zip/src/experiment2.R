setwd("~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/iterative-sdp/src")
source("iterative-reweighting.R")

library(latex2exp)

n <- 1000
p <- 5

Sigma <- eye(p)

num_trials <- 50

for(tr in 1:num_trials) {
  
  print(tr)
  mus <- list()
  
  for(i in 0:50) {
    eps <- i / 100
    X <- flipping_contam(n, p, eps, Sigma)
    
    mu_hat <- mu_IR(X, eps, Sigma, plot=FALSE)
    mus <- c(mus, norm(mu_hat, type="2"))
  }
  
  if(tr >= 1) {
      for(j in 1:51) {
      mu_mean[[j]] <- mu_mean[[j]] + mus[[j]]
    }
  } else {
    mu_mean <- mus
  }
}

for(j in 1:51){
  mu_mean[[j]] <- mu_mean[[j]] / num_trials
}


postscript(file="breakdown.ps")
cl <- rainbow(10)
plot(0.6, 0.5, xlab="eps",
     ylab="l2 loss",
     xlim = c(0,0.5), ylim = c(0,2.3),
     type = "n", main="Breakdown point illustration")
lines(x=c(0:50) / 100, y=mu_mean, type='b', col=cl[1], pch=17)

y <- 0
for(i in c(1:50)) {
  eps <- i / 100
  y <- c(y, eps * sqrt(log(1 / eps)))
}

lines(x=c(0:50) / 100, y=y, type='b', col=cl[2], pch=4)
legend("topleft", legend=c(TeX("$\\hat{\\mu}^{IR}$"),
                           TeX("$\\tilde{\\Omega}(eps)$")),
       col=c(cl[1:2]), pch=c(17, 4), cex=2, pt.cex=1)
dev.off()
