# export PKG_MOSEKHOME=~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/mosek/9.3/tools/platform/osx64x86
# export PKG_MOSEKLIB=mosek64   

library("Rmosek")
mosek_attachbuilder("~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/mosek/9.3/tools/platform/osx64x86/bin")
install.rmosek()

library("Matrix")
# setwd("~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/iterative-sdp/src")

#   python3 ~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/mosek/9.3/tools/platform/osx64x86/python/3/setup.py install --user  
  
library(Gmedian)
library(pracma)
library(MASS)
library(gsubfn)
library(ggplot2)
library(rlist)
library(psych)
library(csv)
library(reticulate)
library(csvread)
suppressWarnings(library(CVXR, warn.conflicts=FALSE))

installed_solvers()

set.seed(1)

write <- function(vec, name) {
  filename = paste(name, ".csv", sep="")
  temp <- file(filename, "wb")
  writeBin(paste(vec, collapse = "\n"), temp)
  close(temp)
}

flipping_contam <- function(n, p, eps, Sigma) {
  mu <- rep(0, p)
  o <- as.numeric(floor(n * eps))
  inliers <- mvrnorm(n=n, mu=mu,Sigma=Sigma)
  
  if (o == 0) {
    return(inliers)
  }
  
  smean <- apply(inliers, 2, mean)
  scov <- outer(inliers[1, ] - smean, inliers[1, ] - smean)
  for(i in 2:n) {
    scov <- scov + outer(inliers[i, ] - smean, inliers[i, ] - smean)
  }
  scov <- scov / n
  
  eigs <- eigen(scov, symmetric=TRUE)
  v1 <- eigs$vectors[p, ]
  
  cors <- c()
  for(i in 1:n){
    cors <- c(cors, abs(cor(v1, inliers[i, ])))
  }
  
  topmost_ind <- head(sort(cors, index.return=TRUE, decreasing=TRUE)$ix, o)
  inliers[topmost_ind, ] <- array_reshape(rep(sqrt(p) * v1, o), dim=c(o, p))
  
  print(norm(apply(inliers[-topmost_ind, ], 2, mean), type="2"))
  return(inliers)
}

generate_X <- function(n, p, eps, Sigma, outlier_type="large") {
  # Generate a matrix of size p times n.
  mu <- rep(0, p)
  o <- as.numeric(floor(n * eps))
  inliers <- mvrnorm(n=n - o, mu=mu, Sigma=Sigma)
  
  if(o == 0) {
    return(inliers)
  }
  
  if (outlier_type == "large") {
    outliers <- matrix(0L, nrow=p, ncol=o)
    for (i in 1:o) {
      theta <- runif(n=p, min=4, max=10)
      outliers[1:p, i] <- mvrnorm(n=1, mu=mu, Sigma=Sigma) + theta
    }
    X <- rbind(inliers, t(outliers))
    return(X)
  } else if (outlier_type == "const") {
    outliers <- 0.5 * ones(p, o)
    X <- rbind(inliers, t(outliers))
    return(X)
  }
  
}

updateWeights <- function(eps, M, Sigma) {
  n <- dim(M)[1] 
  w <- Variable(n, nonneg=TRUE)
  
  M_w <- t(M) %*% w
  M_w <- reshape_expr(M_w, c(p, p))
  
  objective <- Minimize(pos(lambda_max(M_w)))
  constr1 <- list(max_entries(w) <= 1./(n - n * eps))
  constr2 <- list(sum_entries(w) == 1.)
  ptm <- proc.time()
  prob <- Problem(objective, c(constr1, constr2))
  result <- solve(prob, solver="MOSEK", warm_start=TRUE)
  # feastol=sqrt(eps)/10)
  print(c("Optimized in ", proc.time() - ptm))
  
  print(result$status)
  print(result$value)
  return(list(result$getValue(w), result$value))
}

mu_IR <- function (X, eps, Sigma) {
  # X is a matrix of size n times p. 
  # eps is a contamination parameter
  # Sigma is a covariance structure of each X_i. 
  
  n <- NROW(X)
  p <- NCOL(X)
  history <- list()
  
  gm <- geo_median(X)
  mu_0 <- gm$p
  
  if(eps > 0.25 || eps == 0) {
    K <- 10
  } else {
    # K <- 2 + floor(2 * log(18 * sqrt(p + 1), base=exp(1)) / log(1/ (eps * 3), base=exp(1)))
    # nom <- 2 * log(6 * sqrt(p + 1)) + 2 * log(1 / eps)
    nom <- log(4 * tr(Sigma) / norm(Sigma, type="2")) - 2 * log(eps * (1 - 2 * eps))
    denom <- 2 * log(1 - 2 * eps) - log(eps) - log(1 - eps)
    K <- floor(nom / denom)
  }
  
  mu <- mu_0
  
  weight_iters <- lapply(1:K, matrix, data=NA, nrow=1, ncol=n)
  # M <- lapply(1:n, matrix, data=NA, nrow=p, ncol=p)
  
  p2 <- p * p
  nas <- rep(NA, n*p2)
  M <- array(nas, c(n, p2))
  
  for(k in 1:K) {
    print(c("Iteration: ", k))
    ptm <- proc.time()
    for(i in 1:n) {
      M[i, ] <- as.vector(outer(X[i, ] - mu, X[i, ] - mu))
      # M[[i]] <- outer(X[i, ] - mu, X[i, ] - mu)
    }
    print(proc.time() - ptm)
    
    val <- 0
    list[w, val] <- updateWeights(eps, M, Sigma)
    history <- c(history, val)
    
    # print(c("Current weight: ", w))
    # change to weighted mean
    write.csv(file=paste("weights/iter", k), w)
    weight_iters[[k]] <- w
    mu <- rep(0, p)
    for(i in 1:n){
      mu <- mu + w[i] * X[i, ]
    }
    # print(c("Current mu: ", mu))
  }
  
  # write.csv(weight_iters, "data/weights_30.csv", row.names=FALSE)
  print(history)
  
  return(mu)
}

