setwd("~/Yandex.Disk.localized/edu/YSU/all-in-one-robest/iterative-sdp/src")
source("iterative-reweighting.R")

n <- 200
p <- 10
eps <- 0.1
Sigma <- eye(p)

X <- generate_X(n, p, eps, Sigma)
mu_hat <- mu_IR(X, eps, Sigma)
